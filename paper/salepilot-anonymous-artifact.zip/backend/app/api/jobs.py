from fastapi import APIRouter, Depends, Query

from app.services.scheduler import list_jobs, process_due_jobs
from app.api.security import require_admin

router = APIRouter(
    prefix="/jobs",
    tags=["jobs"],
    dependencies=[Depends(require_admin)],
)


@router.get("")
@router.get("/")
async def jobs_list(limit: int = Query(50, ge=1, le=100)):
    return await list_jobs(limit=limit)


@router.post("/tick")
async def jobs_tick():
    """Manual scheduler tick (also runs in background)."""
    n = await process_due_jobs()
    return {"processed": n}
