import json

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.agent.graph import run_agent_stream
from app.agent.trajectory.export import redact_text, redact_trace
from app.services.gateway import ingest_message
from app.services.identity_lock import customer_identity_lock
from app.services.web_session import InvalidWebSession, resolve_web_session

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=4000)
    session_token: str = Field(default="", max_length=256)
    external_id: str = Field(default="", deprecated=True, max_length=128)
    customer_name: str = Field(default="Khách", max_length=128)
    # Retained only for backward-compatible request parsing. Public HTTP chat is
    # always the web channel and conversation ids are resolved server-side.
    channel: str = Field(default="web", deprecated=True)
    conversation_id: int | None = Field(default=None, deprecated=True)


class ChatResponse(BaseModel):
    reply: str
    session_token: str
    conversation_id: int | None = None
    lead_id: int | None = None
    used_agents: list[str] = Field(default_factory=list)
    used_tools: list[str] = Field(default_factory=list)
    trace: list[dict] = Field(default_factory=list)
    needs_human: bool = False
    run_id: str | None = None
    memory: dict | None = None
    memory_summary: str | None = None
    active_skills: list[str] = Field(default_factory=list)


@router.post("", response_model=ChatResponse)
@router.post("/", response_model=ChatResponse)
async def chat(req: ChatRequest) -> ChatResponse:
    try:
        external_id, session_token = resolve_web_session(req.session_token)
    except InvalidWebSession as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(exc),
        ) from exc
    result = await ingest_message(
        channel="web",
        external_id=external_id,
        text=req.message,
        customer_name=req.customer_name,
    )
    return ChatResponse(
        reply=redact_text(result["reply"]),
        session_token=session_token,
        conversation_id=result.get("conversation_id"),
        lead_id=result.get("lead_id"),
        used_agents=result.get("used_agents") or [],
        used_tools=result.get("used_tools") or [],
        trace=redact_trace(result.get("trace") or []),
        needs_human=bool(result.get("needs_human")),
        run_id=result.get("run_id"),
        memory=None,
        memory_summary=redact_text(result.get("memory_summary") or "") or None,
        active_skills=result.get("active_skills") or [],
    )


@router.post("/stream")
async def chat_stream(req: ChatRequest):
    try:
        external_id, session_token = resolve_web_session(req.session_token)
    except InvalidWebSession as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(exc),
        ) from exc
    from app.services.conversation import append_message, get_or_create_conversation, recent_history

    async def event_gen():
        async with customer_identity_lock("web", external_id):
            conv = await get_or_create_conversation(
                channel="web",
                external_id=external_id,
                customer_name=req.customer_name,
            )
            conv_id = conv.id
            await append_message(conv_id, "user", req.message)
            history = await recent_history(conv_id)

            final_reply = ""
            meta: dict = {}
            async for ev in run_agent_stream(
                req.message,
                history=history[:-1],
                channel="web",
                external_id=external_id,
                conversation_id=conv_id,
                lead_id=conv.lead_id,
                customer_name=req.customer_name,
            ):
                if ev.get("type") == "done":
                    final_reply = ev.get("reply") or ""
                    meta = {
                        "used_agents": ev.get("used_agents"),
                        "used_tools": ev.get("used_tools"),
                        "needs_human": ev.get("needs_human"),
                        "trace": ev.get("trace"),
                        "lead_id": ev.get("lead_id"),
                        "run_id": ev.get("run_id"),
                        "conversation_id": conv_id,
                    }
                    ev = {
                        **ev,
                        "conversation_id": conv_id,
                        "session_token": session_token,
                    }
                yield f"data: {json.dumps(ev, ensure_ascii=False)}\n\n"
            if final_reply:
                await append_message(conv_id, "assistant", final_reply, meta=meta)

    return StreamingResponse(event_gen(), media_type="text/event-stream")
