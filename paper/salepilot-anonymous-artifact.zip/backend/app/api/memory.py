from fastapi import APIRouter, Depends, Query

from app.agent.memory.store import list_memories, load_profile
from app.api.security import require_admin

router = APIRouter(
    prefix="/memory",
    tags=["memory"],
    dependencies=[Depends(require_admin)],
)


@router.get("")
@router.get("/")
async def memory_list(limit: int = Query(50, ge=1, le=100)):
    return await list_memories(limit=limit)


@router.get("/{channel}/{external_id}")
async def memory_one(channel: str, external_id: str):
    profile = await load_profile(channel, external_id)
    return {"channel": channel, "external_id": external_id, "profile": profile}
