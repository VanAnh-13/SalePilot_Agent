import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.chat import router as chat_router
from app.api.jobs import router as jobs_router
from app.api.leads import router as leads_router
from app.api.memory import router as memory_router
from app.api.mcp import router as mcp_router
from app.api.outbox import router as outbox_router
from app.api.products import router as products_router
from app.api.runs import router as runs_router
from app.channels.zalo.webhook import router as zalo_router
from app.config import get_settings
from app.db.session import init_db
from app.services.scheduler import scheduler_loop


@asynccontextmanager
async def lifespan(_app: FastAPI):
    Path("data").mkdir(parents=True, exist_ok=True)
    await init_db()
    # Warm the catalog cache (MongoDB primary, snapshot fallback) off the event loop.
    from app.catalog import repository as catalog_repository

    count = await asyncio.to_thread(catalog_repository.load)
    print(f"[catalog] loaded {count} products from {catalog_repository.source()}")
    stop = asyncio.Event()
    task = asyncio.create_task(scheduler_loop(stop))
    try:
        yield
    finally:
        stop.set()
        try:
            await asyncio.wait_for(task, timeout=2.0)
        except (asyncio.TimeoutError, Exception):
            task.cancel()
        from app.services.identity_lock import dispose_identity_lock_engine

        await dispose_identity_lock_engine()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="SalePilot",
        description="AI hỗ trợ so sánh và tư vấn sản phẩm theo nhu cầu, có truy vết nguồn",
        version="0.6.0",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list or ["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(chat_router)
    app.include_router(leads_router)
    app.include_router(products_router)
    app.include_router(outbox_router)
    app.include_router(zalo_router)
    app.include_router(memory_router)
    app.include_router(mcp_router)
    app.include_router(runs_router)
    app.include_router(jobs_router)

    @app.get("/")
    async def ping():
        """Lightweight liveness probe — no DB/catalog access, trả lời tức thì."""
        return {"ping": "pong", "ok": True}

    @app.get("/health")
    async def health():
        from app.catalog import repository as catalog_repository

        return {
            "ok": True,
            "service": "salepilot",
            "architecture": "product-advisor-multi-agent",
            "shop": settings.shop_name,
            "default_category": settings.shop_category,
            "catalog": catalog_repository.metadata(),
            "llm_provider": settings.llm_provider,
            "features": {
                "memory": settings.memory_enabled,
                "sandbox": settings.sandbox_enabled,
                "web_fetch": bool(
                    settings.web_fetch_enabled
                    and settings.web_fetch_allowed_domain_list
                ),
                "scheduler": settings.scheduler_enabled,
                "trajectory": settings.trajectory_enabled,
                "auto_skill_write": settings.auto_skill_write,
            },
        }

    return app


app = create_app()
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
