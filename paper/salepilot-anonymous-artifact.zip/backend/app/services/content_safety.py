"""Neutralize legacy source branding at every public content boundary."""

from __future__ import annotations

import re
from typing import Any

_SOURCE_URL_RE = re.compile(
    r"(?i)(?:https?://)?(?:[a-z0-9-]+\.)*"
    r"(?:dienmayxanh|thegioididong)\.com(?:/\S*)?"
)
_SOURCE_BRAND_RE = re.compile(
    r"(?i)(?:điện\s*máy\s*xanh|thế\s*giới\s*di\s*động|dienmayxanh|thegioididong)"
)


def neutralize_source_branding(value: Any) -> Any:
    """Recursively preserve substance while hiding imported source branding."""

    if isinstance(value, str):
        value = _SOURCE_URL_RE.sub("[nguồn đã ẩn]", value)
        return _SOURCE_BRAND_RE.sub("nhà bán lẻ nguồn", value)
    if isinstance(value, list):
        return [neutralize_source_branding(item) for item in value]
    if isinstance(value, tuple):
        return tuple(neutralize_source_branding(item) for item in value)
    if isinstance(value, dict):
        return {
            neutralize_source_branding(key): neutralize_source_branding(item)
            for key, item in value.items()
        }
    return value
