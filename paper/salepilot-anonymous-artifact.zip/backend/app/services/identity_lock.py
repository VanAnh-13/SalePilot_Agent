"""Serialize one customer's full chat lifecycle across workers."""

from __future__ import annotations

import asyncio
import hashlib
import threading
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import AsyncIterator

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

from app.config import get_settings
from app.db.session import _async_connect_args, engine


@dataclass
class _LockEntry:
    lock: asyncio.Lock
    references: int = 0


_REGISTRY: dict[str, _LockEntry] = {}
_REGISTRY_GUARD = threading.Lock()

# Advisory locks must never consume the main application pool while the locked
# lifecycle opens its own ORM sessions: doing so can deadlock at pool capacity.
# This small, separate pool also acts as an explicit per-worker concurrency cap.
_POSTGRES_LOCK_ENGINE: AsyncEngine | None = None
if engine.dialect.name == "postgresql":
    _settings = get_settings()
    _POSTGRES_LOCK_ENGINE = create_async_engine(
        _settings.database_url,
        echo=False,
        connect_args=_async_connect_args(_settings.database_url),
        pool_size=5,
        max_overflow=0,
        pool_timeout=max(60, _settings.llm_timeout_s * 2),
    )


def _lock_key(channel: str, external_id: str) -> str:
    return f"{channel}\0{external_id}"


def _postgres_lock_id(key: str) -> int:
    return int.from_bytes(
        hashlib.sha256(f"chat-lifecycle\0{key}".encode("utf-8")).digest()[:8],
        byteorder="big",
        signed=True,
    )


def _drop_reference(key: str, entry: _LockEntry) -> None:
    with _REGISTRY_GUARD:
        entry.references -= 1
        if entry.references == 0 and not entry.lock.locked():
            _REGISTRY.pop(key, None)


async def dispose_identity_lock_engine() -> None:
    """Release the auxiliary PostgreSQL pool during application shutdown."""

    if _POSTGRES_LOCK_ENGINE is not None:
        await _POSTGRES_LOCK_ENGINE.dispose()


@asynccontextmanager
async def customer_identity_lock(
    channel: str,
    external_id: str,
) -> AsyncIterator[None]:
    """Prevent two turns for one identity from interleaving.

    The local lock covers every runtime. PostgreSQL also takes a transaction-
    scoped advisory lock on a separate bounded pool, so separate API workers
    serialize conversation creation, history reads and need-memory updates.
    SQLite verification is single-process; its per-write memory path separately
    takes a database write reservation.
    """

    key = _lock_key(channel, external_id)
    with _REGISTRY_GUARD:
        entry = _REGISTRY.get(key)
        if entry is None:
            entry = _LockEntry(lock=asyncio.Lock())
            _REGISTRY[key] = entry
        entry.references += 1

    try:
        await entry.lock.acquire()
    except BaseException:
        _drop_reference(key, entry)
        raise
    try:
        if _POSTGRES_LOCK_ENGINE is None:
            yield
            return

        lock_id = _postgres_lock_id(key)
        async with _POSTGRES_LOCK_ENGINE.connect() as connection:
            async with connection.begin():
                await connection.execute(
                    text("SELECT pg_advisory_xact_lock(:lock_id)"),
                    {"lock_id": lock_id},
                )
                yield
    finally:
        entry.lock.release()
        _drop_reference(key, entry)
