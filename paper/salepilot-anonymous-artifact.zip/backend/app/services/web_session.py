"""Unforgeable bearer sessions for the anonymous public web chat."""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets

from app.config import get_settings

_PROCESS_KEY = secrets.token_bytes(32)
_TOKEN_RE = re.compile(r"^v1\.([0-9a-f]{32})\.([A-Za-z0-9_-]{43})$")


class InvalidWebSession(ValueError):
    """Raised when a supplied public-chat bearer token is malformed or forged."""


def _key() -> bytes:
    configured = get_settings().chat_session_hmac_key
    return configured.encode("utf-8") if configured else _PROCESS_KEY


def _signature(nonce: str) -> str:
    digest = hmac.new(_key(), f"web-session\0{nonce}".encode(), hashlib.sha256).digest()
    return base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")


def create_web_session() -> tuple[str, str]:
    nonce = secrets.token_hex(16)
    return f"web-{nonce}", f"v1.{nonce}.{_signature(nonce)}"


def resolve_web_session(token: str) -> tuple[str, str]:
    """Resolve an existing token, or issue a new anonymous web identity."""

    token = (token or "").strip()
    if not token:
        return create_web_session()
    match = _TOKEN_RE.fullmatch(token)
    if match is None:
        raise InvalidWebSession("invalid web session token")
    nonce, supplied_signature = match.groups()
    if not hmac.compare_digest(supplied_signature, _signature(nonce)):
        raise InvalidWebSession("invalid web session token")
    return f"web-{nonce}", token
