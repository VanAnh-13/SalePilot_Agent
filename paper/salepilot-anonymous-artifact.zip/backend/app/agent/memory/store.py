from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Callable
from copy import deepcopy
from typing import Any

from sqlalchemy import select, text

from app.config import get_settings
from app.db.session import async_session
from app.models.entities import CustomerMemory

DEFAULT_PROFILE: dict[str, Any] = {
    "name": "",
    "phone": "",
    "budget_vnd": None,
    "interests": [],
    "preferred_skus": [],
    "notes": [],
    "last_intent": "",
    # Accumulated need profile (category, budget, slots, priorities) so
    # follow-up turns like "giá khoảng 10tr" keep the earlier context.
    "need": {},
}


def _empty_profile() -> dict[str, Any]:
    return deepcopy(DEFAULT_PROFILE)


def _profile_from_json(payload: str | None) -> dict[str, Any]:
    try:
        data = json.loads(payload or "{}")
    except (json.JSONDecodeError, TypeError):
        data = {}
    profile = _empty_profile()
    if isinstance(data, dict):
        profile.update(data)
    return profile


async def _mutate_profile_atomically(
    channel: str,
    external_id: str,
    mutate: Callable[[dict[str, Any]], None],
) -> dict[str, Any]:
    """Serialize one identity's read/modify/write cycle in SQLite or Postgres.

    SQLite takes a database write reservation before reading. PostgreSQL takes a
    transaction-scoped advisory lock derived from the identity, which also
    serializes the first insert when no row exists yet. Neither path depends on
    the unique constraint already being installed, so pre-migration databases
    remain usable without silently deleting legacy duplicates.
    """
    async with async_session() as session:
        bind = session.get_bind()
        dialect = bind.dialect.name
        if dialect == "sqlite":
            await session.execute(text("BEGIN IMMEDIATE"))
        elif dialect == "postgresql":
            lock_key = int.from_bytes(
                hashlib.sha256(
                    f"{channel}\0{external_id}".encode("utf-8")
                ).digest()[:8],
                byteorder="big",
                signed=True,
            )
            await session.execute(
                text("SELECT pg_advisory_xact_lock(:lock_key)"),
                {"lock_key": lock_key},
            )
        else:  # The configured/tested stores are SQLite and PostgreSQL.
            raise RuntimeError(f"Unsupported memory-store dialect: {dialect}")

        query = select(CustomerMemory).where(
            CustomerMemory.channel == channel,
            CustomerMemory.external_id == external_id,
        ).order_by(CustomerMemory.id.desc()).limit(1)
        if dialect == "postgresql":
            query = query.with_for_update()
        row = (await session.execute(query)).scalar_one_or_none()
        if row is None:
            row = CustomerMemory(
                channel=channel,
                external_id=external_id,
                profile_json=json.dumps(_empty_profile(), ensure_ascii=False),
                summary="",
            )
            session.add(row)
            await session.flush()
        profile = _profile_from_json(row.profile_json)
        mutate(profile)
        row.profile_json = json.dumps(profile, ensure_ascii=False)
        row.summary = await _summary_from_profile(profile)
        await session.commit()
        return profile


async def load_profile(channel: str, external_id: str) -> dict[str, Any]:
    if not get_settings().memory_enabled or not external_id:
        return _empty_profile()
    async with async_session() as session:
        row = (
            await session.execute(
                select(CustomerMemory).where(
                    CustomerMemory.channel == channel,
                    CustomerMemory.external_id == external_id,
                ).order_by(CustomerMemory.id.desc()).limit(1)
            )
        ).scalar_one_or_none()
        if not row:
            return _empty_profile()
        return _profile_from_json(row.profile_json)


async def get_memory_summary(channel: str, external_id: str) -> str:
    """Return the non-sensitive memory context safe for prompts and public APIs.

    Contact details and free-form notes remain available to the CRM workflow,
    but are deliberately excluded here because summaries also appear in traces.
    """
    profile = await load_profile(channel, external_id)
    if not any(
        [
            profile.get("interests"),
            profile.get("preferred_skus"),
            profile.get("budget_vnd"),
        ]
    ):
        return ""
    parts = []
    if profile.get("budget_vnd"):
        parts.append(f"budget≈{int(profile['budget_vnd']):,}".replace(",", ".") + "đ")
    if profile.get("interests"):
        parts.append("quan_tâm=" + ", ".join(profile["interests"][:5]))
    if profile.get("preferred_skus"):
        parts.append("SKU=" + ", ".join(profile["preferred_skus"][:5]))
    return " | ".join(parts)


async def load_need(channel: str, external_id: str) -> dict[str, Any]:
    """Accumulated multi-turn need profile for this customer."""
    profile = await load_profile(channel, external_id)
    need = profile.get("need")
    return dict(need) if isinstance(need, dict) else {}


async def save_need(channel: str, external_id: str, need: dict[str, Any]) -> None:
    if not get_settings().memory_enabled or not external_id:
        return

    def apply(profile: dict[str, Any]) -> None:
        profile["need"] = {
            key: value
            for key, value in need.items()
            if key != "raw" and value not in (None, "", [])
        }

    await _mutate_profile_atomically(channel, external_id, apply)


async def merge_profile(
    channel: str,
    external_id: str,
    *,
    name: str = "",
    phone: str = "",
    budget_vnd: int | None = None,
    interest: str = "",
    sku: str = "",
    note: str = "",
    last_intent: str = "",
) -> dict[str, Any]:
    if not get_settings().memory_enabled or not external_id:
        return _empty_profile()

    def apply(profile: dict[str, Any]) -> None:
        if name:
            profile["name"] = name
        if phone:
            profile["phone"] = phone
        if budget_vnd is not None and budget_vnd > 0:
            profile["budget_vnd"] = budget_vnd
        if interest:
            interests = list(profile.get("interests") or [])
            if interest not in interests:
                interests.append(interest)
            profile["interests"] = interests[-12:]
        if sku:
            skus = list(profile.get("preferred_skus") or [])
            if sku not in skus:
                skus.append(sku)
            profile["preferred_skus"] = skus[-12:]
        if note:
            notes = list(profile.get("notes") or [])
            notes.append(note[:200])
            profile["notes"] = notes[-20:]
        if last_intent:
            profile["last_intent"] = last_intent[:200]

    return await _mutate_profile_atomically(channel, external_id, apply)


async def _summary_from_profile(profile: dict[str, Any]) -> str:
    return json.dumps(profile, ensure_ascii=False)[:500]


async def maybe_extract_from_text(channel: str, external_id: str, text: str) -> dict[str, Any]:
    """Heuristic memory update from user message (offline-safe)."""
    if not get_settings().memory_enabled or not external_id or not text:
        return await load_profile(channel, external_id)

    phone_m = re.search(r"0\d{8,10}", text.replace(" ", "").replace(".", ""))
    interest = ""
    t = text.lower()
    from app.catalog.categories import detect_category

    category = detect_category(text)
    if category:
        interest = category.display.lower()
    # Reuse the robust budget parser (avoids matching "20m2" as 20 triệu).
    from app.agent.catalog_domain import _extract_budget

    budget = _extract_budget(text)

    if not phone_m and not interest and budget is None:
        return await load_profile(channel, external_id)

    return await merge_profile(
        channel,
        external_id,
        phone=phone_m.group(0) if phone_m else "",
        budget_vnd=budget,
        interest=interest,
        last_intent=text[:160],
        note="auto-extract" if phone_m or interest else "",
    )


async def list_memories(limit: int = 50) -> list[dict[str, Any]]:
    async with async_session() as session:
        rows = (
            await session.execute(
                select(CustomerMemory).order_by(CustomerMemory.id.desc()).limit(limit)
            )
        ).scalars().all()
    out = []
    for r in rows:
        try:
            profile = json.loads(r.profile_json or "{}")
        except json.JSONDecodeError:
            profile = {}
        out.append(
            {
                "id": r.id,
                "channel": r.channel,
                "external_id": r.external_id,
                "profile": profile,
                "summary": r.summary,
                "updated_at": r.updated_at.isoformat() if r.updated_at else None,
            }
        )
    return out
