from __future__ import annotations

import asyncio
import ipaddress
import re
import socket
from urllib.parse import urljoin, urlparse

import httpx

from app.config import get_settings

MAX_BYTES = 200_000
MAX_REDIRECTS = 3
_REDIRECT_STATUS = {301, 302, 303, 307, 308}


def _blocked_host(host: str) -> bool:
    host = (host or "").lower().rstrip(".")
    if host in {"localhost", "127.0.0.1", "0.0.0.0", "::1"}:
        return True
    try:
        ip = ipaddress.ip_address(host)
        return not ip.is_global
    except ValueError:
        return False


async def _validate_target(url: str) -> tuple[str, int, str]:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("only http/https")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("URL credentials are not allowed")
    host = (parsed.hostname or "").lower().rstrip(".")
    if not host or _blocked_host(host):
        raise ValueError("private/local host blocked")

    allowed = set(get_settings().web_fetch_allowed_domain_list)
    if host not in allowed:
        raise ValueError("host is not in WEB_FETCH_ALLOWED_DOMAINS")

    try:
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
    except ValueError as exc:
        raise ValueError("invalid URL port") from exc
    expected_port = 443 if parsed.scheme == "https" else 80
    if port != expected_port:
        raise ValueError("only the default HTTP/HTTPS port is allowed")
    try:
        addresses = await asyncio.to_thread(
            socket.getaddrinfo,
            host,
            port,
            0,
            socket.SOCK_STREAM,
        )
    except OSError as exc:
        raise ValueError("host resolution failed") from exc
    resolved = {item[4][0] for item in addresses}
    if not resolved or any(_blocked_host(address) for address in resolved):
        raise ValueError("host resolves to a non-public address")
    # Return a checked address so the network request connects to this exact IP
    # rather than resolving the hostname a second time (DNS rebinding).
    selected = sorted(resolved, key=lambda address: (":" in address, address))[0]
    return host, port, selected


def _pinned_url(url: str, address: str, port: int) -> str:
    parsed = urlparse(url)
    host = f"[{address}]" if ":" in address else address
    return parsed._replace(netloc=f"{host}:{port}").geturl()


async def fetch_page_text(url: str) -> dict:
    if not get_settings().web_fetch_enabled:
        return {"ok": False, "error": "web_fetch disabled"}
    url = (url or "").strip()
    try:
        current_url = url
        async with httpx.AsyncClient(
            timeout=12.0,
            follow_redirects=False,
            trust_env=False,
        ) as client:
            for redirect_count in range(MAX_REDIRECTS + 1):
                host, port, address = await _validate_target(current_url)
                connect_url = _pinned_url(current_url, address, port)
                host_header = f"[{host}]" if ":" in host else host
                async with client.stream(
                    "GET",
                    connect_url,
                    headers={
                        "Host": host_header,
                        "User-Agent": "SalePilotBot/1.0",
                    },
                    extensions={"sni_hostname": host},
                ) as resp:
                    if resp.status_code in _REDIRECT_STATUS:
                        location = resp.headers.get("location")
                        if not location:
                            return {"ok": False, "error": "redirect missing location"}
                        if redirect_count >= MAX_REDIRECTS:
                            return {"ok": False, "error": "too many redirects"}
                        current_url = urljoin(current_url, location)
                        continue

                    raw = bytearray()
                    async for chunk in resp.aiter_bytes():
                        remaining = MAX_BYTES - len(raw)
                        if remaining <= 0:
                            break
                        raw.extend(chunk[:remaining])
                    text = bytes(raw).decode(resp.encoding or "utf-8", errors="replace")
                    # Crude HTML strip; this tool returns text, never active markup.
                    text = re.sub(r"(?is)<script.*?>.*?</script>", " ", text)
                    text = re.sub(r"(?is)<style.*?>.*?</style>", " ", text)
                    text = re.sub(r"(?s)<[^>]+>", " ", text)
                    text = re.sub(r"\s+", " ", text).strip()
                    return {
                        "ok": resp.status_code < 400,
                        "status": resp.status_code,
                        "url": current_url,
                        "text": text[:5000],
                    }
        return {"ok": False, "error": "fetch failed"}
    except (ValueError, httpx.HTTPError) as exc:
        return {"ok": False, "error": str(exc)}
