"""Shared per-turn bag for Lead tools / skills / trace (avoids circular imports)."""

from __future__ import annotations

from contextvars import ContextVar
from typing import Any


def _new_bag() -> dict[str, Any]:
    return {
        "results": [],
        "trace": [],
        "final": None,
        "delegates": 0,
        "active_skills": [],
        "skill_bodies": {},
    }


_run_bag: ContextVar[dict[str, Any] | None] = ContextVar("run_bag", default=None)


def reset_run_bag() -> dict[str, Any]:
    bag = _new_bag()
    _run_bag.set(bag)
    return bag


def get_run_bag() -> dict[str, Any]:
    bag = _run_bag.get()
    if bag is None:
        bag = _new_bag()
        _run_bag.set(bag)
    return bag


def bag_trace(agent: str, event: str, detail: str = "") -> None:
    get_run_bag()["trace"].append({"agent": agent, "event": event, "detail": detail})
