from __future__ import annotations

import hashlib
import hmac
import json
import math
import os
import re
import secrets
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.config import get_settings
from app.db.session import async_session
from app.models.entities import AgentRun

_BACKEND_ROOT = Path(__file__).resolve().parents[3]
_PROCESS_HMAC_KEY = secrets.token_bytes(32)
_CONTENT_DISABLED = "[content capture disabled]"
_EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
_PHONE_RE = re.compile(
    r"(?<!\d)(?:(?:\(\+?84\)|\+?84)(?:[ .-]?\d){9,10}"
    r"|\(0\d{2,3}\)(?:[ .-]?\d){7,8}|0(?:[ .-]?\d){9,10})(?!\d)"
)


def redact_text(value: str) -> str:
    """Remove common direct identifiers from content crossing a public boundary."""
    value = _EMAIL_RE.sub("[redacted-email]", value)
    return _PHONE_RE.sub("[redacted-phone]", value)


def _redact_value(value: Any) -> Any:
    if isinstance(value, str):
        return redact_text(value)
    if isinstance(value, list):
        return [_redact_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _redact_value(item) for key, item in value.items()}
    return value


def redact_trace(trace: list | None, *, include_detail: bool = True) -> list[dict[str, Any]]:
    """Return a JSON-safe trace with identifiers removed.

    Telemetry can retain only the event structure when content capture is off;
    public API responses keep useful redacted details for explainability.
    """
    out: list[dict[str, Any]] = []
    for raw in trace or []:
        if not isinstance(raw, dict):
            continue
        step = {
            "agent": redact_text(str(raw.get("agent") or "")),
            "event": redact_text(str(raw.get("event") or "")),
        }
        if include_detail and raw.get("detail") not in (None, ""):
            step["detail"] = _redact_value(raw["detail"])
        out.append(step)
    return out


def pseudonymize_external_id(channel: str, external_id: str) -> str:
    digest = _pseudonymous_digest(f"{channel}\0{external_id}")
    return f"anon_{digest}"


def _pseudonymous_digest(value: str) -> str:
    settings = get_settings()
    configured_key = settings.telemetry_hmac_key.encode("utf-8")
    key = configured_key or _PROCESS_HMAC_KEY
    return hmac.new(key, value.encode("utf-8"), hashlib.sha256).hexdigest()[:24]


def _safe_number(value: Any, *, maximum: float = 1_000_000_000_000) -> int | float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    numeric = float(value)
    if not math.isfinite(numeric) or numeric < 0 or numeric > maximum:
        return None
    return int(numeric) if numeric.is_integer() else numeric


def _pseudonymize_skus(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    tokens: list[str] = []
    for value in values[:12]:
        if not isinstance(value, str) or not value:
            continue
        digest = _pseudonymous_digest("sku\0" + value)
        tokens.append(f"sku_{digest}")
    return list(dict.fromkeys(tokens))


def _safe_need_snapshot(raw_need: Any) -> dict[str, Any]:
    """Keep only schema-defined recommendation state, never free-form memory."""
    if not isinstance(raw_need, dict):
        return {}

    from app.catalog.categories import get_category

    category = get_category(raw_need.get("category"))
    if category is None:
        return {}

    safe: dict[str, Any] = {"category": category.slug}
    budget = _safe_number(raw_need.get("budget_vnd"))
    if budget is not None:
        safe["budget_vnd"] = budget

    for slot in category.slots:
        value = _safe_number(raw_need.get(slot.key), maximum=1_000_000_000)
        if value is not None:
            safe[slot.key] = value

    allowed_priorities = {priority.key for priority in category.priorities}
    priorities = raw_need.get("priority")
    if isinstance(priorities, list):
        selected = [
            value
            for value in priorities[:12]
            if isinstance(value, str) and value in allowed_priorities
        ]
        if selected:
            safe["priority"] = list(dict.fromkeys(selected))

    for flag in ("budget_flexible", "force"):
        if isinstance(raw_need.get(flag), bool):
            safe[flag] = raw_need[flag]

    sku_tokens = _pseudonymize_skus(raw_need.get("last_skus"))
    if sku_tokens:
        safe["last_sku_tokens"] = sku_tokens
    return safe


def _safe_memory_snapshot(raw_memory: Any) -> dict[str, Any]:
    """Strict telemetry allowlist for customer memory.

    Contact fields, names, notes, last intent, and all unknown/free-form keys are
    omitted. Product identifiers are HMAC-pseudonymized for repeat-analysis.
    """
    if not isinstance(raw_memory, dict):
        return {}

    safe: dict[str, Any] = {}
    budget = _safe_number(raw_memory.get("budget_vnd"))
    if budget is not None:
        safe["budget_vnd"] = budget

    from app.catalog.categories import detect_category

    interests = raw_memory.get("interests")
    if isinstance(interests, list):
        categories = []
        for value in interests[:12]:
            if not isinstance(value, str):
                continue
            category = detect_category(value)
            if category is not None:
                categories.append(category.slug)
        if categories:
            safe["interest_categories"] = list(dict.fromkeys(categories))

    sku_tokens = _pseudonymize_skus(raw_memory.get("preferred_skus"))
    if sku_tokens:
        safe["preferred_sku_tokens"] = sku_tokens

    need = _safe_need_snapshot(raw_memory.get("need"))
    if need:
        safe["need"] = need
    return safe


def _trajectory_dir() -> Path:
    configured = Path(get_settings().trajectory_dir).expanduser()
    return configured if configured.is_absolute() else _BACKEND_ROOT / configured


def _safe_payload(
    *,
    run_id: str,
    channel: str,
    external_id: str,
    conversation_id: int | None,
    user_text: str,
    reply: str,
    trace: list,
    agents: list,
    tools: list,
    memory: dict | None,
    skills: list | None,
) -> dict[str, Any]:
    capture_content = get_settings().trajectory_capture_content
    return {
        "run_id": run_id,
        "ts": datetime.now(timezone.utc).isoformat(),
        "channel": redact_text(channel),
        "external_id": pseudonymize_external_id(channel, external_id),
        # Internal database IDs are direct linkage keys. Research telemetry uses
        # the HMAC external pseudonym for grouping and never persists this ID.
        "conversation_id": None,
        "user_text": redact_text(user_text) if capture_content else _CONTENT_DISABLED,
        "reply": redact_text(reply) if capture_content else _CONTENT_DISABLED,
        "trace": redact_trace(trace, include_detail=capture_content),
        "agents": _redact_value(agents),
        "tools": _redact_value(tools),
        "memory": _safe_memory_snapshot(memory) if capture_content else {},
        "skills": _redact_value(skills or []),
        "content_capture": capture_content,
    }


def _write_private_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        path.parent.chmod(0o700)
    except OSError:
        pass
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


async def save_trajectory(
    *,
    channel: str,
    external_id: str,
    conversation_id: int | None,
    user_text: str,
    reply: str,
    trace: list,
    agents: list,
    tools: list,
    memory: dict | None = None,
    skills: list | None = None,
) -> str | None:
    if not get_settings().trajectory_enabled:
        return None

    run_id = uuid.uuid4().hex[:16]
    payload = _safe_payload(
        run_id=run_id,
        channel=channel,
        external_id=external_id,
        conversation_id=conversation_id,
        user_text=user_text,
        reply=reply,
        trace=trace,
        agents=agents,
        tools=tools,
        memory=memory,
        skills=skills,
    )

    _write_private_json(_trajectory_dir() / f"{run_id}.json", payload)

    async with async_session() as session:
        session.add(
            AgentRun(
                run_id=run_id,
                channel=payload["channel"],
                external_id=payload["external_id"],
                conversation_id=payload["conversation_id"],
                user_text=payload["user_text"][:2000],
                reply=payload["reply"][:4000],
                trace_json=json.dumps(payload["trace"], ensure_ascii=False),
                agents_json=json.dumps(payload["agents"], ensure_ascii=False),
                tools_json=json.dumps(payload["tools"], ensure_ascii=False),
                memory_json=json.dumps(payload["memory"], ensure_ascii=False),
                skills_json=json.dumps(payload["skills"], ensure_ascii=False),
            )
        )
        await session.commit()
    return run_id
