"""Read-only shell over a dedicated non-sensitive filesystem jail."""

from __future__ import annotations

import asyncio
import shlex
import stat
from pathlib import Path

from app.config import get_settings

ALLOW_BIN = {"date", "pwd", "ls", "wc", "head", "cat", "echo"}
_BACKEND_ROOT = Path(__file__).resolve().parents[3]

_NO_FILE_COMMANDS = {"date", "pwd", "echo"}
_SAFE_FLAG_CHARS = {
    "cat": frozenset("nbsetvAET"),
    "wc": frozenset("lwcmL"),
    "ls": frozenset("alh1"),
}


def _sandbox_root() -> Path:
    configured = Path(get_settings().sandbox_root).expanduser()
    root = configured if configured.is_absolute() else _BACKEND_ROOT / configured
    if root.is_symlink():
        raise ValueError("sandbox root cannot be a symlink")
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    root.chmod(0o700)
    return root.resolve()


def _jailed_path(raw: str) -> str:
    """Resolve an operand inside the dedicated jail and reject unsafe nodes."""
    root = _sandbox_root()
    supplied = Path(raw)
    candidate = supplied if supplied.is_absolute() else root / supplied
    try:
        relative = candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"path outside sandbox jail: {raw}") from exc

    cursor = root
    for component in relative.parts:
        cursor = cursor / component
        if cursor.is_symlink():
            raise ValueError(f"symlinks are not allowed in sandbox jail: {raw}")

    resolved = candidate.resolve(strict=False)
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"path outside sandbox jail: {raw}") from exc
    if resolved.exists():
        mode = resolved.stat(follow_symlinks=False).st_mode
        if not (stat.S_ISREG(mode) or stat.S_ISDIR(mode)):
            raise ValueError(f"special files are not allowed in sandbox jail: {raw}")
    return str(resolved)


def _normalized_argv(binary: str, args: list[str]) -> list[str]:
    """Apply a small command grammar and rewrite every file operand.

    Merely checking a derived path is insufficient: subprocess must receive the
    canonical jailed path, never the caller-supplied operand.
    """
    if binary in _NO_FILE_COMMANDS:
        if binary == "pwd" and any(arg not in {"-L", "-P"} for arg in args):
            raise ValueError("pwd accepts only -L or -P")
        if binary == "date" and any(not arg.startswith("+") for arg in args):
            raise ValueError("date accepts only an optional +FORMAT")
        return [binary, *args]

    normalized = [binary]
    index = 0
    while index < len(args):
        arg = args[index]
        if arg == "--":
            raise ValueError("option terminator is not supported")

        if binary == "head" and arg in {"-n", "--lines"}:
            if index + 1 >= len(args) or not args[index + 1].isdigit():
                raise ValueError("head line count must be a non-negative integer")
            normalized.extend(["-n", args[index + 1]])
            index += 2
            continue
        if binary == "head" and (
            (arg.startswith("-n") and arg[2:].isdigit())
            or (arg.startswith("--lines=") and arg.removeprefix("--lines=").isdigit())
            or (arg.startswith("-") and arg[1:].isdigit())
        ):
            normalized.append(arg)
            index += 1
            continue

        if arg.startswith("-"):
            flags = arg[1:]
            if not flags or binary == "head" or not set(flags) <= _SAFE_FLAG_CHARS[binary]:
                raise ValueError(f"unsupported {binary} option: {arg}")
            normalized.append(arg)
            index += 1
            continue

        normalized.append(_jailed_path(arg))
        index += 1
    return normalized


async def run_sandbox_command(cmd: str, timeout: float = 5.0) -> dict:
    if not get_settings().sandbox_enabled:
        return {"ok": False, "error": "sandbox disabled"}

    cmd = (cmd or "").strip()
    if not cmd:
        return {"ok": False, "error": "empty command"}

    try:
        parts = shlex.split(cmd)
    except ValueError as e:
        return {"ok": False, "error": f"parse error: {e}"}

    if not parts:
        return {"ok": False, "error": "empty"}

    binary = Path(parts[0]).name
    if binary not in ALLOW_BIN:
        return {"ok": False, "error": f"denied binary '{binary}'. allow: {sorted(ALLOW_BIN)}"}

    try:
        root = _sandbox_root()
        safe_parts = _normalized_argv(binary, parts[1:])
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    try:
        proc = await asyncio.create_subprocess_exec(
            *safe_parts,
            cwd=str(root),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            return {"ok": False, "error": "timeout"}
        return {
            "ok": proc.returncode == 0,
            "code": proc.returncode,
            "stdout": stdout.decode("utf-8", errors="replace")[:4000],
            "stderr": stderr.decode("utf-8", errors="replace")[:1000],
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}
