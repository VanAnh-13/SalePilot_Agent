"""Regression tests for the deterministic conference evaluation harness."""

from __future__ import annotations

import math
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from pydantic import ValidationError

from evaluation.dataset import load_scenarios
from evaluation.metrics import (
    explanation_claim_fidelity,
    hard_constraint_score,
    hit_at_k,
    ndcg_at_k,
    precision_at_1,
    recall_at_k,
)
from evaluation.report import render_markdown
from evaluation.runner import (
    CatalogFixtureError,
    evaluate,
    load_catalog,
    validate_catalog_references,
)
from evaluation.schema import Prediction, Scenario


class ScenarioSchemaTest(unittest.TestCase):
    def test_schema_rejects_blank_turns_and_incomplete_recommendation_gold(self) -> None:
        base = {
            "schema_version": "1.0",
            "dataset_id": "test-v1",
            "scenario_id": "valid_id",
            "language": "vi",
            "turns": [""],
            "gold": {
                "category": "tu_lanh",
                "action": "recommend",
                "relevant_items": [{"sku": "FRIDGE-SYN-001", "relevance": 1}],
                "hard_constraints": [],
            },
            "tags": [],
        }
        with self.assertRaises(ValidationError):
            Scenario.model_validate(base)

        base["turns"] = ["Tôi cần tủ lạnh dưới 15 triệu"]
        base["gold"]["relevant_items"] = []
        with self.assertRaises(ValidationError):
            Scenario.model_validate(base)

    def test_versioned_dataset_and_manifest_load_together(self) -> None:
        scenarios = load_scenarios()
        self.assertEqual(8, len(scenarios))
        self.assertEqual("salepilot-scenarios-v1", scenarios[0].dataset_id)
        self.assertEqual(len(scenarios), len({item.scenario_id for item in scenarios}))

    def test_catalog_rejects_duplicate_skus_despite_matching_hash_and_count(self) -> None:
        products = [
            {"sku": "DUPLICATE", "category": "tu_lanh"},
            {"sku": "DUPLICATE", "category": "tu_lanh"},
        ]
        raw = json.dumps(products, ensure_ascii=False).encode("utf-8")
        manifest = {
            "catalog_id": "invalid-duplicate",
            "schema_version": "1.0",
            "sha256": hashlib.sha256(raw).hexdigest(),
            "product_count": 2,
            "categories": {"tu_lanh": 2},
        }
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "catalog.json"
            path.write_bytes(raw)
            path.with_suffix(".manifest.json").write_text(
                json.dumps(manifest),
                encoding="utf-8",
            )
            with self.assertRaisesRegex(CatalogFixtureError, "unique"):
                load_catalog(path)

    def test_catalog_rejects_gold_sku_missing_from_fixture(self) -> None:
        scenarios = load_scenarios()
        catalog = tuple(
            product
            for product in load_catalog()
            if product["sku"] != "FRIDGE-SYN-001"
        )
        with self.assertRaisesRegex(CatalogFixtureError, "missing SKU"):
            validate_catalog_references(scenarios, catalog)


class MetricMathTest(unittest.TestCase):
    def test_ir_metric_math(self) -> None:
        ranked = ("B", "A", "X")
        relevant = {"A", "B"}
        grades = {"A": 3, "B": 1}

        self.assertEqual(1.0, precision_at_1(ranked, relevant))
        self.assertEqual(1.0, hit_at_k(ranked, relevant, 3))
        self.assertEqual(1.0, recall_at_k(ranked, relevant, 3))
        expected_ndcg = (1 + 7 / math.log2(3)) / (7 + 1 / math.log2(3))
        self.assertAlmostEqual(expected_ndcg, ndcg_at_k(ranked, grades, 3))

    def test_hard_constraint_score_is_product_level_and_missing_fails(self) -> None:
        scenario = Scenario.model_validate(
            {
                "schema_version": "1.0",
                "dataset_id": "test-v1",
                "scenario_id": "constraint_case",
                "language": "vi",
                "turns": ["Tủ lạnh dưới 15 triệu"],
                "gold": {
                    "category": "tu_lanh",
                    "action": "recommend",
                    "relevant_items": [{"sku": "A", "relevance": 1}],
                    "hard_constraints": [
                        {"field": "price_vnd", "operator": "le", "value": 15_000_000},
                        {"field": "has_inverter", "operator": "eq", "value": True},
                    ],
                },
            }
        )
        prediction = Prediction(
            scenario_id="constraint_case",
            system_id="test",
            category="tu_lanh",
            action="recommend",
            recommended_skus=("A", "B", "MISSING"),
            latency_ms=0,
        )
        catalog = {
            "A": {"sku": "A", "price_vnd": 14_000_000, "norm": {"has_inverter": True}},
            "B": {"sku": "B", "price_vnd": 16_000_000, "norm": {"has_inverter": True}},
        }
        self.assertAlmostEqual(1 / 3, hard_constraint_score(prediction, scenario, catalog))

    def test_false_range_fit_explanation_claim_fails_fidelity_check(self) -> None:
        prediction = Prediction(
            scenario_id="false_explanation",
            system_id="test",
            category="tu_lanh",
            action="recommend",
            recommended_skus=("TOO-LARGE",),
            explanations={"TOO-LARGE": "phù hợp số người dùng"},
            need={"household_size": 4},
            latency_ms=0,
        )
        catalog = {
            "TOO-LARGE": {
                "sku": "TOO-LARGE",
                "norm": {"household_min": 5, "household_max": 6},
            }
        }
        self.assertEqual((0, 1), explanation_claim_fidelity(prediction, catalog))

        truthful_fallback = prediction.model_copy(
            update={
                "explanations": {
                    "TOO-LARGE": "ngoài dải số người dùng (5–6)"
                }
            }
        )
        self.assertEqual(
            (1, 1),
            explanation_claim_fidelity(truthful_fallback, catalog),
        )


class OfflineEvaluationTest(unittest.TestCase):
    def test_zero_latency_mode_is_fully_deterministic(self) -> None:
        first = evaluate(measure_latency=False)
        second = evaluate(measure_latency=False)
        self.assertEqual(first, second)
        self.assertFalse(first["validity"]["recommendation_efficacy_supported"])
        self.assertTrue(first["validity"]["categories_with_candidate_count_le_3"])
        fidelity = first["systems"]["stateful_need"]["metrics"]["limited_claim_fidelity"]
        self.assertEqual(1.0, fidelity["precision"])
        self.assertGreater(fidelity["supported_claims"], 0)
        for payload in first["systems"].values():
            metrics = payload["metrics"]
            self.assertEqual(8, metrics["support"]["action"])
            self.assertGreaterEqual(metrics["action_accuracy"], 0.0)
            self.assertLessEqual(metrics["action_accuracy"], 1.0)

    def test_stateful_need_accumulation_beats_last_turn_on_multiturn_cases(self) -> None:
        scenarios = {scenario.scenario_id: scenario for scenario in load_scenarios()}
        multi_turn_ids = {
            scenario.scenario_id
            for scenario in scenarios.values()
            if "multi_turn" in scenario.tags
        }
        result = evaluate(measure_latency=False)
        stateful = {
            item["scenario_id"]: item
            for item in result["systems"]["stateful_need"]["predictions"]
        }
        stateless = {
            item["scenario_id"]: item
            for item in result["systems"]["stateless_last_turn"]["predictions"]
        }

        stateful_correct = sum(
            stateful[item_id]["category"] == scenarios[item_id].gold.category
            and stateful[item_id]["action"] == "recommend"
            for item_id in multi_turn_ids
        )
        stateless_correct = sum(
            stateless[item_id]["category"] == scenarios[item_id].gold.category
            and stateless[item_id]["action"] == "recommend"
            for item_id in multi_turn_ids
        )
        self.assertEqual(len(multi_turn_ids), stateful_correct)
        self.assertGreater(stateful_correct, stateless_correct)

    def test_popularity_baseline_does_not_read_gold_action(self) -> None:
        result = evaluate(measure_latency=False)
        baseline = result["systems"]["popularity_oracle_category"]
        predictions = {
            item["scenario_id"]: item
            for item in baseline["predictions"]
        }

        # Given only the gold category, a popularity ranker recommends instead
        # of magically reproducing the clarification label.
        self.assertEqual(
            "recommend",
            predictions["fridge_requires_clarification"]["action"],
        )
        self.assertEqual(
            2,
            baseline["metrics"]["support"]["clarification_escalation"],
        )
        self.assertEqual(
            0.5,
            baseline["metrics"]["clarification_escalation_proxy_accuracy"],
        )

    def test_markdown_report_carries_validity_warning_and_paper_metrics(self) -> None:
        markdown = render_markdown(evaluate(measure_latency=False))
        self.assertIn("Validity warning", markdown)
        self.assertIn("not an external effectiveness benchmark", markdown)
        self.assertIn("Hard constraints", markdown)
        self.assertIn("Action acc.", markdown)
        self.assertIn("nDCG@3", markdown)
        self.assertIn("Clarify/escalate proxy", markdown)
        self.assertIn("Limited claim fidelity", markdown)
        self.assertIn("not a human judgment of explanation quality", markdown)


if __name__ == "__main__":
    unittest.main()
