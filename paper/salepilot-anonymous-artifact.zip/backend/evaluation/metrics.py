"""Transparent IR, constraint, action and latency metrics."""

from __future__ import annotations

import math
from statistics import fmean
from typing import Any, Iterable

from app.catalog.categories import get_category

from .schema import HardConstraint, Prediction, Scenario


def hit_at_k(ranked: Iterable[str], relevant: set[str], k: int = 3) -> float:
    return float(bool(set(list(ranked)[:k]) & relevant))


def recall_at_k(ranked: Iterable[str], relevant: set[str], k: int = 3) -> float:
    if not relevant:
        return 0.0
    return len(set(list(ranked)[:k]) & relevant) / len(relevant)


def precision_at_1(ranked: Iterable[str], relevant: set[str]) -> float:
    first = list(ranked)[:1]
    return float(bool(first and first[0] in relevant))


def ndcg_at_k(ranked: Iterable[str], grades: dict[str, int], k: int = 3) -> float:
    def dcg(values: list[int]) -> float:
        return sum((2**grade - 1) / math.log2(index + 2) for index, grade in enumerate(values))

    observed = [grades.get(sku, 0) for sku in list(ranked)[:k]]
    ideal = sorted(grades.values(), reverse=True)[:k]
    denominator = dcg(ideal)
    return dcg(observed) / denominator if denominator else 0.0


def _product_value(product: dict[str, Any], field: str) -> Any:
    if field in product:
        return product[field]
    return (product.get("norm") or {}).get(field)


def satisfies(product: dict[str, Any], constraint: HardConstraint) -> bool:
    actual = _product_value(product, constraint.field)
    if actual is None:
        return False
    expected = constraint.value
    try:
        if constraint.operator == "le":
            return float(actual) <= float(expected)
        if constraint.operator == "ge":
            return float(actual) >= float(expected)
        if constraint.operator == "eq":
            return actual == expected
        return str(expected).casefold() in str(actual).casefold()
    except (TypeError, ValueError):
        return False


def hard_constraint_score(
    prediction: Prediction,
    scenario: Scenario,
    catalog_by_sku: dict[str, dict[str, Any]],
) -> float:
    constraints = scenario.gold.hard_constraints
    if not constraints:
        return 1.0
    if not prediction.recommended_skus:
        return 0.0
    return fmean(
        float(
            sku in catalog_by_sku
            and all(
                satisfies(catalog_by_sku[sku], constraint)
                for constraint in constraints
            )
        )
        for sku in prediction.recommended_skus
    )


def explanation_claim_fidelity(
    prediction: Prediction,
    catalog_by_sku: dict[str, dict[str, Any]],
) -> tuple[int, int]:
    """Return ``(verified, recognized)`` for mechanically checkable claims.

    This intentionally ignores persuasive, comparative and qualitative text.
    A recognized claim with missing evidence counts as false; unrecognized text
    is outside the metric rather than optimistically treated as correct.
    """

    category = get_category(prediction.category)
    range_slots = {
        slot.label.casefold(): slot
        for slot in (category.slots if category else ())
        if slot.kind == "range_fit"
    }
    verified = 0
    recognized = 0
    for sku in prediction.recommended_skus:
        product = catalog_by_sku.get(sku)
        explanation = prediction.explanations.get(sku, "")
        for raw_claim in explanation.split(";"):
            claim = " ".join(raw_claim.casefold().strip().split())
            if claim == "trong ngân sách":
                recognized += 1
                budget = prediction.need.get("budget_vnd")
                price = _product_value(product, "price_vnd") if product else None
                if budget is not None and price is not None and float(price) <= float(budget):
                    verified += 1
                continue

            expected_fit: bool | None = None
            label = ""
            if claim.startswith("phù hợp "):
                expected_fit = True
                label = claim.removeprefix("phù hợp ").strip()
            elif claim.startswith("ngoài dải "):
                expected_fit = False
                label = claim.removeprefix("ngoài dải ").strip()
            slot = next(
                (
                    candidate
                    for configured_label, candidate in range_slots.items()
                    if label == configured_label
                    or label.startswith(f"{configured_label} (")
                ),
                None,
            )
            if expected_fit is None or slot is None:
                continue

            recognized += 1
            target = prediction.need.get(slot.key)
            low = _product_value(product, f"{slot.range_key}_min") if product else None
            high = _product_value(product, f"{slot.range_key}_max") if product else None
            if target is None or low is None:
                continue
            fits = float(target) >= float(low) and (
                high is None or float(target) <= float(high)
            )
            if fits is expected_fit:
                verified += 1
    return verified, recognized


def _percentile(values: list[float], percentile: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(0, math.ceil(percentile * len(ordered)) - 1)
    return ordered[index]


def aggregate_metrics(
    scenarios: tuple[Scenario, ...],
    predictions: tuple[Prediction, ...],
    catalog: tuple[dict[str, Any], ...],
) -> dict[str, Any]:
    """Compute macro metrics with explicit support counts."""

    if len(scenarios) != len(predictions):
        raise ValueError("one prediction is required for every scenario")
    by_sku = {str(product.get("sku")): product for product in catalog}
    pairs = list(zip(scenarios, predictions, strict=True))
    category_pairs = [(s, p) for s, p in pairs if s.gold.category is not None]
    recommendation_pairs = [(s, p) for s, p in pairs if s.gold.action == "recommend"]
    clarification_escalation_pairs = [
        (s, p)
        for s, p in pairs
        if s.gold.action in {"clarify", "escalate"}
    ]

    category_accuracy = fmean(
        float(prediction.category == scenario.gold.category)
        for scenario, prediction in category_pairs
    ) if category_pairs else 0.0
    action_accuracy = fmean(
        float(prediction.action == scenario.gold.action)
        for scenario, prediction in pairs
    ) if pairs else 0.0
    clarification_escalation_accuracy = fmean(
        float(prediction.action == scenario.gold.action)
        for scenario, prediction in clarification_escalation_pairs
    ) if clarification_escalation_pairs else 0.0

    hits: list[float] = []
    precisions: list[float] = []
    recalls: list[float] = []
    ndcgs: list[float] = []
    constraints: list[float] = []
    for scenario, prediction in recommendation_pairs:
        grades = {item.sku: item.relevance for item in scenario.gold.relevant_items}
        relevant = set(grades)
        hits.append(hit_at_k(prediction.recommended_skus, relevant))
        precisions.append(precision_at_1(prediction.recommended_skus, relevant))
        recalls.append(recall_at_k(prediction.recommended_skus, relevant))
        ndcgs.append(ndcg_at_k(prediction.recommended_skus, grades))
        constraints.append(hard_constraint_score(prediction, scenario, by_sku))

    latency = [prediction.latency_ms for prediction in predictions]
    verified_claims = 0
    recognized_claims = 0
    for prediction in predictions:
        verified, recognized = explanation_claim_fidelity(prediction, by_sku)
        verified_claims += verified
        recognized_claims += recognized
    return {
        "category_accuracy": round(category_accuracy, 6),
        "hard_constraint_satisfaction": round(fmean(constraints), 6) if constraints else 0.0,
        "hit_at_3": round(fmean(hits), 6) if hits else 0.0,
        "precision_at_1": round(fmean(precisions), 6) if precisions else 0.0,
        "recall_at_3": round(fmean(recalls), 6) if recalls else 0.0,
        "ndcg_at_3": round(fmean(ndcgs), 6) if ndcgs else 0.0,
        "action_accuracy": round(action_accuracy, 6),
        "clarification_escalation_proxy_accuracy": round(
            clarification_escalation_accuracy,
            6,
        ),
        "limited_claim_fidelity": {
            "precision": (
                round(verified_claims / recognized_claims, 6)
                if recognized_claims
                else None
            ),
            "verified_claims": verified_claims,
            "supported_claims": recognized_claims,
            "scope": (
                "Mechanically checked budget and configured range-fit claims only; "
                "not a measure of human explanation quality."
            ),
        },
        "latency_ms": {
            "mean": round(fmean(latency), 6) if latency else 0.0,
            "p50": round(_percentile(latency, 0.50), 6),
            "p95": round(_percentile(latency, 0.95), 6),
            "max": round(max(latency), 6) if latency else 0.0,
        },
        "support": {
            "all_scenarios": len(pairs),
            "action": len(pairs),
            "category": len(category_pairs),
            "recommendation": len(recommendation_pairs),
            "clarification_escalation": len(clarification_escalation_pairs),
        },
    }
