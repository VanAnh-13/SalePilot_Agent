"""Command-line entry point for reproducible paper evaluation."""

from __future__ import annotations

import argparse
from pathlib import Path

from .dataset import DEFAULT_CATALOG_PATH, DEFAULT_SCENARIO_PATH
from .report import write_reports
from .runner import evaluate


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenarios", type=Path, default=DEFAULT_SCENARIO_PATH)
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG_PATH)
    parser.add_argument("--json-out", type=Path, required=True)
    parser.add_argument("--markdown-out", type=Path, required=True)
    parser.add_argument(
        "--deterministic-latency",
        action="store_true",
        help="Record zero latency for byte-stable regression reports.",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    result = evaluate(
        scenario_path=args.scenarios,
        catalog_path=args.catalog,
        measure_latency=not args.deterministic_latency,
    )
    write_reports(result, json_path=args.json_out, markdown_path=args.markdown_out)
    print(f"wrote {args.json_out} and {args.markdown_out}")


if __name__ == "__main__":
    main()
