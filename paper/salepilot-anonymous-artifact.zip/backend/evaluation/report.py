"""Machine-readable and paper-table report writers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def render_markdown(result: dict[str, Any]) -> str:
    dataset = result["dataset"]
    catalog = result["catalog"]
    validity_warning = " ".join(result["validity"]["warnings"])
    lines = [
        "# SalePilot offline evaluation",
        "",
        f"Dataset: `{dataset['dataset_id']}` (`{dataset['scenario_count']}` scenarios, SHA-256 `{dataset['sha256']}`).",
        f"Catalog: `{catalog['catalog_id']}` (`{catalog['product_count']}` synthetic products, SHA-256 `{catalog['sha256']}`).",
        "",
        f"> **Validity warning:** {validity_warning}",
        "",
        "| System | Category acc. | Action acc. | Hard constraints | P@1 | Hit@3 | Recall@3 | nDCG@3 | Clarify/escalate proxy | Limited claim fidelity | Claim support | Mean latency (ms) | P95 latency (ms) |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for system_id, payload in result["systems"].items():
        metrics = payload["metrics"]
        latency = metrics["latency_ms"]
        fidelity = metrics["limited_claim_fidelity"]
        fidelity_display = (
            f"{fidelity['precision']:.3f}"
            if fidelity["precision"] is not None
            else "n/a"
        )
        lines.append(
            "| "
            + " | ".join(
                [
                    f"`{system_id}`",
                    f"{metrics['category_accuracy']:.3f}",
                    f"{metrics['action_accuracy']:.3f}",
                    f"{metrics['hard_constraint_satisfaction']:.3f}",
                    f"{metrics['precision_at_1']:.3f}",
                    f"{metrics['hit_at_3']:.3f}",
                    f"{metrics['recall_at_3']:.3f}",
                    f"{metrics['ndcg_at_3']:.3f}",
                    f"{metrics['clarification_escalation_proxy_accuracy']:.3f}",
                    fidelity_display,
                    str(fidelity["supported_claims"]),
                    f"{latency['mean']:.3f}",
                    f"{latency['p95']:.3f}",
                ]
            )
            + " |"
        )
    lines.extend(
        [
            "",
            "The popularity baseline receives the gold category but ignores user constraints. "
            "Latency covers local parsing and ranking only; no network or LLM call is used.",
            "Action accuracy is the three-way exact match over all gold "
            "recommend/clarify/escalate scenarios.",
            "Clarify/escalate proxy accuracy is computed only on gold clarify/escalate "
            "scenarios; recommendation cases are excluded from that denominator.",
            "",
            "Limited claim fidelity checks only recognized `trong ngân sách`, configured "
            "`phù hợp <range slot>`, and `ngoài dải <range slot>` claims against structured "
            "need/catalog fields. It is not a human judgment of explanation quality, "
            "completeness, usefulness, or fluency.",
            "",
            "This file is generated from the versioned fixtures; rerun the evaluator rather than editing measured values.",
            "",
        ]
    )
    return "\n".join(lines)


def write_reports(
    result: dict[str, Any],
    *,
    json_path: Path | str,
    markdown_path: Path | str,
) -> None:
    json_target = Path(json_path)
    markdown_target = Path(markdown_path)
    json_target.parent.mkdir(parents=True, exist_ok=True)
    markdown_target.parent.mkdir(parents=True, exist_ok=True)
    json_target.write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    markdown_target.write_text(render_markdown(result), encoding="utf-8")
