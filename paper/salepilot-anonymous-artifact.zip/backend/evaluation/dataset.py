"""Load and integrity-check the versioned JSONL scenario dataset."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from .schema import SCENARIO_SCHEMA_VERSION, Scenario

DEFAULT_SCENARIO_PATH = Path(__file__).resolve().parent / "data" / "scenarios_v1.jsonl"
DEFAULT_CATALOG_PATH = Path(__file__).resolve().parent / "data" / "catalog_synthetic_v1.json"


class DatasetIntegrityError(ValueError):
    """Raised when bytes, metadata or scenario rows violate the contract."""


class DatasetManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    dataset_id: str = Field(min_length=1)
    schema_version: str
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    scenario_count: int = Field(ge=1)
    language: str
    license: str


def _manifest_path(path: Path) -> Path:
    return path.with_suffix(".manifest.json")


def load_scenarios(path: Path | str = DEFAULT_SCENARIO_PATH) -> tuple[Scenario, ...]:
    """Return validated scenarios after checking the companion manifest."""

    source = Path(path)
    manifest_path = _manifest_path(source)
    try:
        raw = source.read_bytes()
        manifest = DatasetManifest.model_validate_json(manifest_path.read_text(encoding="utf-8"))
    except (OSError, ValidationError, json.JSONDecodeError) as exc:
        raise DatasetIntegrityError(f"Cannot load evaluation dataset: {source}") from exc

    digest = hashlib.sha256(raw).hexdigest()
    if digest != manifest.sha256:
        raise DatasetIntegrityError(
            f"Scenario SHA-256 mismatch: expected {manifest.sha256}, got {digest}"
        )
    if manifest.schema_version != SCENARIO_SCHEMA_VERSION:
        raise DatasetIntegrityError(
            f"Unsupported scenario schema {manifest.schema_version!r}"
        )

    scenarios: list[Scenario] = []
    for line_number, line in enumerate(raw.decode("utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            item: Any = json.loads(line)
            scenario = Scenario.model_validate(item)
        except (json.JSONDecodeError, ValidationError) as exc:
            raise DatasetIntegrityError(
                f"Invalid scenario at {source.name}:{line_number}"
            ) from exc
        if scenario.dataset_id != manifest.dataset_id:
            raise DatasetIntegrityError(
                f"Dataset id mismatch at {source.name}:{line_number}"
            )
        scenarios.append(scenario)

    if len(scenarios) != manifest.scenario_count:
        raise DatasetIntegrityError(
            f"Scenario count mismatch: expected {manifest.scenario_count}, got {len(scenarios)}"
        )
    ids = [scenario.scenario_id for scenario in scenarios]
    if len(ids) != len(set(ids)):
        raise DatasetIntegrityError("scenario_id values must be unique")
    return tuple(scenarios)
