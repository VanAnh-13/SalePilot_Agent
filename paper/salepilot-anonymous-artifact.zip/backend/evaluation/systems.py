"""Offline adapters for the target system and transparent baselines."""

from __future__ import annotations

from time import perf_counter
from typing import Callable

from app.agent.catalog_domain import (
    extract_need_from_text,
    merge_needs,
    recommend_top3,
    resolve_followup_answer,
)
from app.catalog import repository
from app.catalog.categories import detect_category, detect_unsupported, get_category

from .schema import Prediction, Scenario

Clock = Callable[[], float]


def _action(result: dict, text: str) -> str:
    if detect_unsupported(text):
        return "escalate"
    if result.get("need_more"):
        return "clarify"
    return "recommend" if result.get("top3") else "escalate"


def _prediction(
    *,
    scenario: Scenario,
    system_id: str,
    need: dict,
    result: dict,
    elapsed_ms: float,
) -> Prediction:
    top = result.get("top3") or []
    return Prediction(
        scenario_id=scenario.scenario_id,
        system_id=system_id,
        category=result.get("category") or need.get("category"),
        action=_action(result, scenario.turns[-1]),
        recommended_skus=tuple(str(item["sku"]) for item in top[:3]),
        explanations={
            str(item["sku"]): str(item["why"])
            for item in top[:3]
            if item.get("why")
        },
        need={key: value for key, value in need.items() if key != "raw"},
        latency_ms=round(elapsed_ms, 6),
    )


def stateful_need_system(
    scenario: Scenario,
    *,
    clock: Clock = perf_counter,
    measure_latency: bool = True,
) -> Prediction:
    """Target: accumulate typed needs across all turns, then rank with SalePilot."""

    started = clock() if measure_latency else 0.0
    need: dict = {}
    for turn in scenario.turns:
        detected = detect_category(turn)
        context_category = (detected.slug if detected else None) or need.get("category")
        fresh = extract_need_from_text(turn, context_category)
        previous = need
        need = merge_needs(previous, fresh)
        switching = bool(
            detected
            and previous.get("category")
            and detected.slug != previous.get("category")
        )
        if not switching:
            need = resolve_followup_answer(need, previous, turn)
    result = recommend_top3(need)
    elapsed = (clock() - started) * 1000 if measure_latency else 0.0
    return _prediction(
        scenario=scenario,
        system_id="stateful_need",
        need=need,
        result=result,
        elapsed_ms=elapsed,
    )


def stateless_last_turn_system(
    scenario: Scenario,
    *,
    clock: Clock = perf_counter,
    measure_latency: bool = True,
) -> Prediction:
    """Ablation: discard prior turns and reason from only the final utterance."""

    started = clock() if measure_latency else 0.0
    need = extract_need_from_text(scenario.turns[-1])
    result = recommend_top3(need)
    elapsed = (clock() - started) * 1000 if measure_latency else 0.0
    return _prediction(
        scenario=scenario,
        system_id="stateless_last_turn",
        need=need,
        result=result,
        elapsed_ms=elapsed,
    )


def popularity_oracle_category_system(
    scenario: Scenario,
    *,
    clock: Clock = perf_counter,
    measure_latency: bool = True,
) -> Prediction:
    """Non-personalized baseline: oracle category, then units sold/rating.

    Giving this simple baseline the judged category makes it a stronger and
    more interpretable comparator: any remaining gain comes from constraint
    handling and ranking rather than category detection.
    """

    started = clock() if measure_latency else 0.0
    category = get_category(scenario.gold.category)
    if category:
        products = repository.by_category(category.code)
        ranked = sorted(
            (product for product in products if product.get("price_vnd") is not None),
            key=lambda product: (
                -int(product.get("sold") or 0),
                -float(product.get("rating") or 0),
                int(product.get("price_vnd") or 10**15),
                str(product.get("sku") or ""),
            ),
        )
        need = {"category": scenario.gold.category}
        result = {
            "category": scenario.gold.category,
            "need_more": False,
            "top3": [{"sku": product["sku"]} for product in ranked[:3]],
        }
    else:
        # The baseline receives only the judged category. When it is absent,
        # the shared action policy may still identify an explicitly unsupported
        # request from text, but it never reads the gold action label.
        need = {}
        result = {"need_more": False, "top3": []}
    elapsed = (clock() - started) * 1000 if measure_latency else 0.0
    prediction = _prediction(
        scenario=scenario,
        system_id="popularity_oracle_category",
        need=need,
        result=result,
        elapsed_ms=elapsed,
    )
    return prediction


SYSTEMS = (
    stateful_need_system,
    stateless_last_turn_system,
    popularity_oracle_category_system,
)
