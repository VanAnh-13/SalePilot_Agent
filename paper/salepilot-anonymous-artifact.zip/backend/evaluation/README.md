# Offline evaluation harness

This harness evaluates deterministic SalePilot need extraction and catalog
ranking without a database, network connection, API key, or LLM. It compares:

- `stateful_need`: the target multi-turn need accumulator and ranker;
- `stateless_last_turn`: an ablation that forgets previous turns;
- `popularity_oracle_category`: a non-personalized units-sold baseline that is
  given the gold category and ignores user constraints.

Run it from `backend/`:

```bash
.venv/bin/python -m evaluation.cli \
  --json-out /tmp/salepilot-evaluation.json \
  --markdown-out /tmp/salepilot-evaluation.md
```

Use `--deterministic-latency` for byte-stable regression output. The normal
mode measures local parse-and-rank latency. Both the scenario JSONL file and
the catalog fixture have companion manifests with schema versions, counts and
SHA-256 digests. Loading also rejects duplicate/blank catalog SKUs, category
count drift, unsupported schemas and gold relevance labels that do not resolve
to a product in the evaluated category.

## Validity boundary

`synthetic-v1` is a functional and reproducibility fixture. Each category has
only three candidates, so Hit@3 and Recall@3 are non-discriminative. The
harness reports them to keep the future external-benchmark interface stable,
but the more informative fixture checks are constraint satisfaction, P@1,
nDCG@3, category behavior, three-way action accuracy, clarify/escalate behavior
and determinism. Action accuracy covers every recommend/clarify/escalate case;
the narrower clarification/escalation proxy is computed only over scenarios
whose gold action is one of those two decisions. The limited claim-fidelity
metric mechanically checks only recognized budget and configured range-fit
claims against structured fields. Its support count is always reported; it is
not a human evaluation of explanation quality, completeness, usefulness or
fluency. Do not claim real-world recommendation efficacy from these synthetic
scores alone.

The CLI accepts `--scenarios` and `--catalog`, so a future independently
annotated benchmark with larger candidate pools can reuse the same schema,
systems and metrics without checking measured results into the repository.
