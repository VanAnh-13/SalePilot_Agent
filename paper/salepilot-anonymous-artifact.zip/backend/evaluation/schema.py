"""Versioned public schema for evaluation scenarios and predictions."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

SCENARIO_SCHEMA_VERSION = "1.0"
EVALUATION_SCHEMA_VERSION = "1.0"


class HardConstraint(BaseModel):
    """One machine-checkable requirement over a flattened product record."""

    model_config = ConfigDict(extra="forbid")

    field: str = Field(min_length=1)
    operator: Literal["le", "ge", "eq", "contains"]
    value: str | int | float | bool


class RelevantItem(BaseModel):
    """A judged product with an integer relevance grade."""

    model_config = ConfigDict(extra="forbid")

    sku: str = Field(min_length=1)
    relevance: int = Field(default=1, ge=1, le=3)


class GoldAnswer(BaseModel):
    """Ground truth used by the offline metrics."""

    model_config = ConfigDict(extra="forbid")

    category: str | None = None
    action: Literal["recommend", "clarify", "escalate"]
    relevant_items: tuple[RelevantItem, ...] = ()
    hard_constraints: tuple[HardConstraint, ...] = ()

    @model_validator(mode="after")
    def validate_recommendation_judgments(self) -> "GoldAnswer":
        skus = [item.sku for item in self.relevant_items]
        if len(skus) != len(set(skus)):
            raise ValueError("relevant_items must contain unique SKUs")
        if self.action == "recommend" and (not self.category or not skus):
            raise ValueError("recommend scenarios require category and relevant_items")
        if self.action != "recommend" and skus:
            raise ValueError("non-recommend scenarios cannot contain relevant_items")
        return self


class Scenario(BaseModel):
    """One Vietnamese, possibly multi-turn, shopping scenario."""

    model_config = ConfigDict(extra="forbid")

    schema_version: Literal["1.0"]
    dataset_id: str = Field(min_length=1)
    scenario_id: str = Field(pattern=r"^[a-z0-9][a-z0-9_-]+$")
    language: Literal["vi"] = "vi"
    turns: tuple[str, ...] = Field(min_length=1)
    gold: GoldAnswer
    tags: tuple[str, ...] = ()

    @model_validator(mode="after")
    def reject_blank_turns(self) -> "Scenario":
        if any(not turn.strip() for turn in self.turns):
            raise ValueError("turns cannot contain blank text")
        return self


class Prediction(BaseModel):
    """Normalized output shared by every evaluated system."""

    model_config = ConfigDict(extra="forbid")

    scenario_id: str
    system_id: str
    category: str | None
    action: Literal["recommend", "clarify", "escalate"]
    recommended_skus: tuple[str, ...] = ()
    explanations: dict[str, str] = Field(default_factory=dict)
    need: dict[str, Any] = Field(default_factory=dict)
    latency_ms: float = Field(ge=0)
