"""Evaluation orchestration with an isolated synthetic catalog."""

from __future__ import annotations

import hashlib
import json
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from app.catalog import repository

from .dataset import DEFAULT_CATALOG_PATH, DEFAULT_SCENARIO_PATH, load_scenarios
from .metrics import aggregate_metrics
from .schema import EVALUATION_SCHEMA_VERSION, Prediction, Scenario
from .systems import SYSTEMS


class CatalogFixtureError(ValueError):
    """Raised when the frozen synthetic catalog fails its manifest checks."""


class CatalogManifest(BaseModel):
    model_config = ConfigDict(extra="allow")

    catalog_id: str = Field(min_length=1)
    schema_version: str
    sha256: str = Field(pattern=r"^[0-9a-f]{64}$")
    product_count: int = Field(ge=1)
    categories: dict[str, int]


def load_catalog(path: Path | str = DEFAULT_CATALOG_PATH) -> tuple[dict[str, Any], ...]:
    source = Path(path)
    manifest_path = source.with_suffix(".manifest.json")
    try:
        raw = source.read_bytes()
        products = json.loads(raw)
        manifest = CatalogManifest.model_validate_json(
            manifest_path.read_text(encoding="utf-8")
        )
    except (OSError, ValidationError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise CatalogFixtureError(f"Cannot load catalog fixture: {source}") from exc
    if not isinstance(products, list):
        raise CatalogFixtureError("catalog fixture must be a JSON array")
    if manifest.schema_version != "1.0":
        raise CatalogFixtureError(
            f"unsupported catalog schema {manifest.schema_version!r}"
        )
    if hashlib.sha256(raw).hexdigest() != manifest.sha256:
        raise CatalogFixtureError("catalog fixture SHA-256 does not match its manifest")
    if len(products) != manifest.product_count:
        raise CatalogFixtureError("catalog fixture count does not match its manifest")
    if any(not isinstance(product, dict) for product in products):
        raise CatalogFixtureError("every catalog product must be an object")

    skus = [str(product.get("sku") or "").strip() for product in products]
    if any(not sku for sku in skus):
        raise CatalogFixtureError("every catalog product requires a non-empty SKU")
    if len(skus) != len(set(skus)):
        raise CatalogFixtureError("catalog SKU values must be unique")

    category_counts: dict[str, int] = {}
    for product in products:
        category = str(product.get("category") or "").strip()
        if not category:
            raise CatalogFixtureError("every catalog product requires a category")
        category_counts[category] = category_counts.get(category, 0) + 1
    if category_counts != manifest.categories:
        raise CatalogFixtureError("catalog category counts do not match its manifest")
    return tuple(products)


def validate_catalog_references(
    scenarios: tuple[Scenario, ...],
    catalog: tuple[dict[str, Any], ...],
) -> None:
    """Ensure every judged recommendation points into the evaluated catalog."""

    category_by_sku = {
        str(product["sku"]): str(product.get("category") or "")
        for product in catalog
    }
    for scenario in scenarios:
        for relevant in scenario.gold.relevant_items:
            if relevant.sku not in category_by_sku:
                raise CatalogFixtureError(
                    f"scenario {scenario.scenario_id} references missing SKU {relevant.sku}"
                )
            if category_by_sku[relevant.sku] != scenario.gold.category:
                raise CatalogFixtureError(
                    f"scenario {scenario.scenario_id} references SKU {relevant.sku} "
                    "from a different category"
                )


@contextmanager
def _isolated_repository(
    catalog: tuple[dict[str, Any], ...],
    catalog_path: Path | str,
) -> Iterator[None]:
    """Temporarily expose the fixture through the application's repository API."""

    manifest = json.loads(Path(catalog_path).with_suffix(".manifest.json").read_text(encoding="utf-8"))
    with repository._LOCK:  # Evaluation-only injection; restored before returning.
        old = (
            repository._CACHE,
            repository._LOADED,
            repository._SOURCE,
            repository._DISTINCT_CATS,
            repository._SNAPSHOT_MANIFEST,
        )
        repository._CACHE = list(catalog)
        repository._LOADED = True
        repository._SOURCE = "snapshot"
        repository._DISTINCT_CATS = None
        repository._SNAPSHOT_MANIFEST = manifest
    try:
        yield
    finally:
        with repository._LOCK:
            (
                repository._CACHE,
                repository._LOADED,
                repository._SOURCE,
                repository._DISTINCT_CATS,
                repository._SNAPSHOT_MANIFEST,
            ) = old


def _run_system(
    system,
    scenarios: tuple[Scenario, ...],
    *,
    measure_latency: bool,
) -> tuple[Prediction, ...]:
    return tuple(
        system(scenario, measure_latency=measure_latency)
        for scenario in scenarios
    )


def evaluate(
    *,
    scenario_path: Path | str = DEFAULT_SCENARIO_PATH,
    catalog_path: Path | str = DEFAULT_CATALOG_PATH,
    measure_latency: bool = True,
) -> dict[str, Any]:
    """Run all systems and return a JSON-serializable result dictionary."""

    scenarios = load_scenarios(scenario_path)
    catalog = load_catalog(catalog_path)
    validate_catalog_references(scenarios, catalog)
    scenario_manifest = json.loads(
        Path(scenario_path).with_suffix(".manifest.json").read_text(encoding="utf-8")
    )
    catalog_manifest = json.loads(
        Path(catalog_path).with_suffix(".manifest.json").read_text(encoding="utf-8")
    )
    systems: dict[str, Any] = {}
    with _isolated_repository(catalog, catalog_path):
        for system in SYSTEMS:
            predictions = _run_system(system, scenarios, measure_latency=measure_latency)
            system_id = predictions[0].system_id
            systems[system_id] = {
                "metrics": aggregate_metrics(scenarios, predictions, catalog),
                "predictions": [prediction.model_dump(mode="json") for prediction in predictions],
            }

    candidate_counts: dict[str, int] = {}
    for product in catalog:
        category = str(product.get("category") or "unknown")
        candidate_counts[category] = candidate_counts.get(category, 0) + 1
    limited_categories = sorted(
        category for category, count in candidate_counts.items() if count <= 3
    )

    return {
        "evaluation_schema_version": EVALUATION_SCHEMA_VERSION,
        "dataset": {
            "dataset_id": scenario_manifest["dataset_id"],
            "schema_version": scenario_manifest["schema_version"],
            "sha256": scenario_manifest["sha256"],
            "scenario_count": scenario_manifest["scenario_count"],
        },
        "catalog": {
            "catalog_id": catalog_manifest["catalog_id"],
            "schema_version": catalog_manifest["schema_version"],
            "sha256": catalog_manifest["sha256"],
            "product_count": catalog_manifest["product_count"],
        },
        "validity": {
            "tier": "functional_reproducibility",
            "recommendation_efficacy_supported": False,
            "candidate_count_by_category": candidate_counts,
            "warnings": [
                "Synthetic-v1 is a functional fixture, not an external effectiveness benchmark.",
                "Hit@3 and Recall@3 are non-discriminative when a category has at most three candidates."
                if limited_categories
                else "Candidate pools exceed k=3 for all evaluated categories.",
                "Do not use these synthetic-v1 scores alone to claim real-world recommendation efficacy.",
            ],
            "categories_with_candidate_count_le_3": limited_categories,
        },
        "systems": systems,
    }
