"""Deterministic, offline evaluation harness for SalePilot.

The package deliberately keeps evaluation data, system adapters, metrics and
report rendering separate.  That makes a paper result reproducible without
coupling the benchmark to the HTTP server or an external LLM.
"""

from .dataset import DEFAULT_SCENARIO_PATH, load_scenarios
from .runner import evaluate

__all__ = ["DEFAULT_SCENARIO_PATH", "evaluate", "load_scenarios"]
