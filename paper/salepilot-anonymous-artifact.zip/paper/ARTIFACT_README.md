# SalePilot anonymous evaluation artifact

This supplement reproduces the **same-team functional repeatability** results
reported in the SalePilot system/protocol paper. It is not an external
effectiveness benchmark and does not execute the Lead orchestrator, LLM,
databases, channel gateway, persistence lifecycle, or user interface.

## Frozen inputs

- Scenarios: `backend/evaluation/data/scenarios_v1.jsonl` (8 cases), SHA-256
  `2e69892d8e127bc4e73747d545bb973425be950844315f9907f03ef9c8f8dda0`
- Catalog: `backend/evaluation/data/catalog_synthetic_v1.json` (24 products),
  SHA-256
  `f3d5803344c320f5c6e1cb52c586f1d9c93af0015c1d57194aa77059b8817b4e`
- Both inputs require their companion manifest files.

## Run

Use Python 3.12 in a virtual environment. From the extracted archive root:

```bash
python -m venv backend/.venv
backend/.venv/bin/pip install -r backend/requirements.txt
cd backend
.venv/bin/python -m evaluation.cli \
  --json-out ../paper/artifacts/evaluation_deterministic.json \
  --markdown-out ../paper/artifacts/evaluation_deterministic.md \
  --deterministic-latency
.venv/bin/python -m unittest tests.test_evaluation
```

The deterministic command requires no API key, database, network request, or
proprietary catalog. Compare regenerated digests with
`paper/artifacts/artifact_manifest.json`.

## Interpretation boundary

- Turns are replayed open-loop; only the final prediction is scored.
- `stateful_need` and `stateless_last_turn` execute only deterministic
  extraction, state merge, action normalization, and ranking.
- The legacy output label `escalate` means evaluator fallback/out-of-scope; it
  is not proof that a production human-handoff tool ran.
- In `limited_claim_fidelity`, the legacy key `supported_claims` is the count of
  recognized claims (the denominator), while `verified_claims` is the
  numerator.
- Three products per category make Hit@3 and Recall@3 non-discriminative.
- The labels are developer-authored and do not support real-world efficacy,
  generalization, human explanation quality, or multi-agent superiority.

The archive intentionally excludes `.env`, credentials, databases, customer
records, caches, and generated virtual environments.
